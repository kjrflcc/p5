function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  // Face  
  ellipse(200, 55, 100, 100);
  // Body
  rect(150, 110, 100, 100);
  // Left Leg 
  line(150, 200, 150, 300);
  line(175, 210, 175, 300);
  // Right Leg
  line(225, 210, 225, 300);
  line(250, 210, 250, 300);
}